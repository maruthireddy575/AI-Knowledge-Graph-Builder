import pandas as pd


def relationships_to_dataframe(
    relationships
):

    if not relationships:

        return pd.DataFrame(
            columns=[
                "Source",
                "Relation",
                "Target"
            ]
        )

    dataframe = pd.DataFrame(
        relationships,
        columns=[
            "Source",
            "Relation",
            "Target"
        ]
    )

    return dataframe


def calculate_graph_statistics(
    graph
):

    stats = {

        "Total Nodes":
        graph.number_of_nodes(),

        "Total Edges":
        graph.number_of_edges(),

        "Density":
        round(graph.number_of_edges() /
        max(graph.number_of_nodes(), 1), 2)
    }

    return stats