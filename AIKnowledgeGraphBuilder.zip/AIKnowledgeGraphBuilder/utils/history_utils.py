import json
from datetime import datetime


HISTORY_FILE = "outputs/logs/history.json"


def load_history():

    try:

        with open(
            HISTORY_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    except:

        return []


def save_history(
    topic,
    concepts,
    relationships
):

    history = load_history()

    entry = {

        "timestamp": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        ),

        "topic": topic,

        "concept_count": len(concepts),

        "relationship_count": len(
            relationships
        ),

        "top_concepts": concepts[:5]
    }

    history.append(entry)

    with open(
        HISTORY_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            history,
            file,
            indent=4
        )


def clear_history():

    with open(
        HISTORY_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump([], file)