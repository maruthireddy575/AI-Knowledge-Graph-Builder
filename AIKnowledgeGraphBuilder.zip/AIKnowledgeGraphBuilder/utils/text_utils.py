import re


def clean_input_text(text):

    text = re.sub(
        r"\s+",
        " ",
        text
    )

    return text.strip()


def split_into_sentences(text):

    sentences = re.split(
        r'(?<=[.!?]) +',
        text
    )

    return sentences


def word_count(text):

    words = text.split()

    return len(words)


def character_count(text):

    return len(text)