sample_topics = {

    "Cybersecurity": """
    Cybersecurity protects systems, networks, and sensitive data from cyber attacks.
    Firewalls monitor incoming and outgoing traffic across networks.
    Encryption secures confidential information during communication.
    Authentication verifies user identity before access is granted.
    Intrusion detection systems identify suspicious activities in a network.
    Malware can damage systems and steal confidential information.
    """,

    "Machine Learning": """
    Machine learning enables computers to learn from data.
    Neural networks are used in deep learning models.
    Training data improves model accuracy over time.
    Supervised learning uses labeled datasets for prediction.
    Classification algorithms identify categories from input data.
    Artificial intelligence powers automation and intelligent decision making.
    """,

    "Computer Networks": """
    Computer networks allow communication between devices.
    Routers forward packets across multiple networks.
    Switches connect devices within local area networks.
    TCP ensures reliable communication between systems.
    IP addressing identifies devices on a network.
    Wireless networks use access points for connectivity.
    """,

    "Cloud Computing": """
    Cloud computing delivers computing services over the internet.
    Virtual machines provide scalable infrastructure resources.
    Data centers store and manage cloud resources.
    SaaS applications are accessed through web browsers.
    Load balancers distribute traffic across servers.
    Cloud security protects user data and services.
    """
}