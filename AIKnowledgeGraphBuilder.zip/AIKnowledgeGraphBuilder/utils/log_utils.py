from datetime import datetime


LOG_FILE = "outputs/logs/agent_logs.txt"


def get_timestamp():

    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


def write_log(message):

    timestamp = get_timestamp()

    formatted_message = (
        f"[{timestamp}] {message}\n"
    )

    with open(
        LOG_FILE,
        "a",
        encoding="utf-8"
    ) as file:

        file.write(formatted_message)


def clear_logs():

    with open(
        LOG_FILE,
        "w",
        encoding="utf-8"
    ) as file:

        file.write("")


def read_logs():

    try:

        with open(
            LOG_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            return file.read()

    except:

        return "No logs available."