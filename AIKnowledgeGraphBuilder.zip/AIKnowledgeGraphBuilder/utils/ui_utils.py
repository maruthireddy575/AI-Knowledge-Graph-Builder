import streamlit as st


def section_header(title):

    st.markdown(
        f"""
        <div style="
            background-color:#1F2937;
            padding:12px;
            border-radius:10px;
            margin-top:15px;
            margin-bottom:10px;
        ">
            <h3 style="
                color:white;
                margin:0;
            ">
                {title}
            </h3>
        </div>
        """,
        unsafe_allow_html=True
    )


def metric_card(
    label,
    value
):

    st.markdown(
        f"""
        <div style="
            background-color:#111827;
            padding:20px;
            border-radius:12px;
            text-align:center;
            border:1px solid #374151;
        ">
            <h4 style="
                color:#9CA3AF;
                margin-bottom:10px;
            ">
                {label}
            </h4>

            <h2 style="
                color:white;
            ">
                {value}
            </h2>
        </div>
        """,
        unsafe_allow_html=True
    )


def display_validation_item(
    label,
    status
):

    if status:

        st.success(f"✔ {label}")

    else:

        st.error(f"✘ {label}")