import spacy
from itertools import combinations

nlp = spacy.load("en_core_web_sm")


RELATION_KEYWORDS = {

    "protect": "protects",
    "monitor": "monitors",
    "secure": "secures",
    "verify": "verifies",
    "detect": "detects",
    "connect": "connects",
    "store": "stores",
    "transfer": "transfers",
    "use": "uses",
    "improve": "improves",
    "support": "supports",
    "analyze": "analyzes",
    "enable": "enables",
    "block": "blocks",
    "manage": "manages",
    "control": "controls",
    "identify": "identifies",
    "forward": "forwards",
    "train": "trains",
    "learn": "learns",
    "predict": "predicts"
}


def clean_text(text):

    return text.strip().title()


def detect_relation(sentence):

    sentence_lower = sentence.lower()

    for keyword, relation in RELATION_KEYWORDS.items():

        if keyword in sentence_lower:

            return relation

    return "related_to"


def extract_sentence_concepts(
    sentence,
    concepts
):

    matches = []

    sentence_lower = sentence.lower()

    for concept in concepts:

        if concept.lower() in sentence_lower:

            matches.append(concept)

    return matches


def extract_relationships(
    text,
    concepts
):

    doc = nlp(text)

    relationships = []

    seen = set()

    for sent in doc.sents:

        sentence = sent.text.strip()

        matched_concepts = extract_sentence_concepts(
            sentence,
            concepts
        )

        if len(matched_concepts) < 2:
            continue

        relation = detect_relation(sentence)

        # Create clean concept pairs
        for source, target in combinations(
            matched_concepts[:4],
            2
        ):

            if source.lower() == target.lower():
                continue

            normalized = (
                source.lower(),
                relation,
                target.lower()
            )

            if normalized in seen:
                continue

            relationships.append({

                "source": clean_text(source),

                "relation": relation,

                "target": clean_text(target),

                "sentence": sentence
            })

            seen.add(normalized)

    return relationships[:18]