import re
import spacy
from collections import Counter

nlp = spacy.load("en_core_web_sm")


STOP_PHRASES = {

    "this",
    "that",
    "these",
    "those",
    "system",
    "systems",
    "information"
}


def clean_text(text):

    text = re.sub(
        r"\s+",
        " ",
        text
    )

    return text.strip()


def extract_noun_phrases(doc):

    phrases = []

    for chunk in doc.noun_chunks:

        phrase = chunk.text.strip()

        if (
            len(phrase) > 3
            and phrase.lower()
            not in STOP_PHRASES
        ):

            phrases.append(phrase)

    return phrases


def extract_named_entities(doc):

    entities = []

    for ent in doc.ents:

        entity = ent.text.strip()

        if len(entity) > 3:

            entities.append(entity)

    return entities


def extract_keywords(doc):

    keywords = []

    important_pos = [

        "NOUN",

        "PROPN"
    ]

    for token in doc:

        if (

            token.pos_ in important_pos

            and not token.is_stop

            and len(token.text) > 3
        ):

            keywords.append(
                token.text
            )

    return keywords


def rank_concepts(concepts):

    counter = Counter(concepts)

    ranked = sorted(

        counter.items(),

        key=lambda x: (

            x[1],

            len(x[0])
        ),

        reverse=True
    )

    return ranked


def extract_concepts(text):

    cleaned_text = clean_text(
        text
    )

    doc = nlp(cleaned_text)

    noun_phrases = extract_noun_phrases(
        doc
    )

    entities = extract_named_entities(
        doc
    )

    keywords = extract_keywords(
        doc
    )

    combined = (

        noun_phrases

        + entities

        + keywords
    )

    ranked = rank_concepts(
        combined
    )

    final_concepts = []

    seen = set()

    for concept, _ in ranked:

        normalized = (
            concept.lower().strip()
        )

        if normalized not in seen:

            final_concepts.append(
                concept.title()
            )

            seen.add(normalized)

    return final_concepts[:18]