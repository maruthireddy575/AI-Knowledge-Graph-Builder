def validate_pipeline(
    concepts,
    relationships,
    graph
):

    validation = {}

    validation["Concept Extraction"] = (
        len(concepts) >= 5
    )

    validation["Relationship Mapping"] = (
        len(relationships) >= 3
    )

    validation["Graph Generation"] = (
        graph.number_of_nodes() >= 5
    )

    validation["Graph Connectivity"] = (
        graph.number_of_edges() >= 3
    )

    validation["Semantic Refinement"] = (
        len(concepts) > 0
    )

    passed_checks = sum(
        value
        for value in validation.values()
    )

    total_checks = len(validation)

    validation["Pipeline Score"] = (
        f"{passed_checks}/{total_checks}"
    )

    if passed_checks == total_checks:

        validation["Pipeline Status"] = (
            "Optimal"
        )

    elif passed_checks >= 3:

        validation["Pipeline Status"] = (
            "Stable"
        )

    else:

        validation["Pipeline Status"] = (
            "Needs Improvement"
        )

    return validation