from deepdiff import DeepDiff


def generate_diff(

    original_concepts,

    refined_concepts
):

    diff = DeepDiff(

        original_concepts,

        refined_concepts,

        ignore_order=True
    )

    added = []

    removed = []

    if "iterable_item_added" in diff:

        added = list(
            diff["iterable_item_added"].values()
        )

    if "iterable_item_removed" in diff:

        removed = list(
            diff["iterable_item_removed"].values()
        )

    formatted = {

        "Original Concept Count":
        len(original_concepts),

        "Refined Concept Count":
        len(refined_concepts),

        "Added Concepts":
        added,

        "Removed Concepts":
        removed,

        "Total Changes":
        len(added) + len(removed)
    }

    return formatted