import networkx as nx
from pyvis.network import Network


CATEGORY_COLORS = {

    "security": "#EF4444",
    "technology": "#3B82F6",
    "process": "#8B5CF6",
    "data": "#F59E0B",
    "default": "#10B981"
}


def detect_category(node):

    node_lower = node.lower()

    if any(word in node_lower for word in [
        "firewall",
        "malware",
        "encryption",
        "authentication",
        "security"
    ]):
        return "security"

    if any(word in node_lower for word in [
        "network",
        "router",
        "cloud",
        "server",
        "model",
        "neural"
    ]):
        return "technology"

    if any(word in node_lower for word in [
        "training",
        "learning",
        "analysis",
        "prediction"
    ]):
        return "process"

    if any(word in node_lower for word in [
        "data",
        "traffic",
        "identity",
        "information"
    ]):
        return "data"

    return "default"


def build_graph(relationships):

    graph = nx.Graph()

    for item in relationships:

        source = item["source"]

        target = item["target"]

        relation = item["relation"]

        sentence = item["sentence"]

        graph.add_node(
            source,
            category=detect_category(source)
        )

        graph.add_node(
            target,
            category=detect_category(target)
        )

        graph.add_edge(

            source,

            target,

            label=relation,

            sentence=sentence
        )

    return graph


def generate_pyvis_graph(
    graph,
    output_path="outputs/graph.html"
):

    network = Network(

        height="820px",

        width="100%",

        bgcolor="#0F172A",

        font_color="white",

        notebook=False
    )

    network.barnes_hut(

        gravity=-2200,

        central_gravity=0.25,

        spring_length=170,

        spring_strength=0.02,

        damping=0.92
    )

    degree_map = dict(graph.degree())

    # Better node visuals
    for node, data in graph.nodes(data=True):

        category = data.get(
            "category",
            "default"
        )

        degree = degree_map.get(
            node,
            1
        )

        size = min(
            18 + (degree * 5),
            45
        )

        tooltip = (
        f"Concept: {node}\n"
        f"Category: {category.title()}\n"
        f"Connections: {degree}\n\n"
        f"Explore connected concepts."
        )

        network.add_node(

            node,

            label=node,

            title=tooltip,

            color=CATEGORY_COLORS.get(
                category,
                CATEGORY_COLORS["default"]
            ),

            size=size,

            borderWidth=2,

            shape="dot"
        )

    # Cleaner edges
    for source, target, data in graph.edges(data=True):

        relation = data.get(
            "label",
            ""
        )

        sentence = data.get(
            "sentence",
            ""
        )

        edge_tooltip = (
        f"Relationship: {relation}\n\n"
        f"Context: {sentence}"
        )

        network.add_edge(

            source,

            target,

            title=edge_tooltip,

            label=relation,

            color={
                "color": "#64748B",
                "highlight": "#E2E8F0"
            },

            width=2,

            smooth={
                "enabled": True,
                "type": "curvedCW"
            }
        )

    network.set_options("""
    const options = {

      "nodes": {

        "font": {
          "size": 16,
          "face": "Inter",
          "color": "white"
        },

        "shadow": {
          "enabled": true,
          "size": 14
        }
      },

      "edges": {

        "font": {
          "size": 11,
          "strokeWidth": 0
        },

        "shadow": false,

        "selectionWidth": 2
      },

      "interaction": {

        "hover": true,

        "hoverConnectedEdges": true,

        "navigationButtons": true,

        "keyboard": true
      },

      "physics": {

        "enabled": true,

        "solver": "barnesHut",

        "barnesHut": {

          "gravitationalConstant": -2200,

          "centralGravity": 0.25,

          "springLength": 170,

          "springConstant": 0.02
        },

        "stabilization": {

          "enabled": true,

          "iterations": 120
        }
      }
    }
    """)

    network.save_graph(
        output_path
    )

    return output_path