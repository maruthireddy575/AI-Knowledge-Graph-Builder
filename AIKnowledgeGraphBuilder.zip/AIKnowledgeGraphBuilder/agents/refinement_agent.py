STOPWORDS = {

    "system",
    "systems",
    "technology",
    "technologies",
    "information",
    "process",
    "processes"
}


def normalize_concept(concept):

    return concept.strip().lower()


def singularize(word):

    if word.endswith("s") and len(word) > 4:

        return word[:-1]

    return word


def remove_noise(concepts):

    cleaned = []

    for concept in concepts:

        normalized = normalize_concept(
            concept
        )

        if len(normalized) <= 2:
            continue

        if normalized in STOPWORDS:
            continue

        cleaned.append(normalized)

    return cleaned


def remove_duplicates(concepts):

    unique = []

    seen = set()

    for concept in concepts:

        normalized = singularize(
            concept
        )

        if normalized not in seen:

            unique.append(normalized)

            seen.add(normalized)

    return unique


def prioritize_meaningful_concepts(
    concepts
):

    ranked = sorted(

        concepts,

        key=lambda x: (
            len(x.split()),
            len(x)
        ),

        reverse=True
    )

    return ranked


def refine_concepts(concepts):

    # Step 1
    cleaned = remove_noise(
        concepts
    )

    # Step 2
    unique = remove_duplicates(
        cleaned
    )

    # Step 3
    prioritized = prioritize_meaningful_concepts(
        unique
    )

    # Step 4
    refined = [

        concept.title()

        for concept in prioritized
    ]

    return refined[:15]