import streamlit as st
import streamlit.components.v1 as components
import pandas as pd

from agents.extraction_agent import extract_concepts
from agents.relation_agent import extract_relationships
from agents.graph_builder_agent import (
    build_graph,
    generate_pyvis_graph
)

from agents.refinement_agent import refine_concepts
from agents.validation_agent import validate_pipeline
from agents.diff_viewer_agent import generate_diff

from utils.sample_inputs import sample_topics
from utils.log_utils import write_log
from utils.history_utils import (
    save_history,
    load_history
)


st.set_page_config(
    page_title="AI Knowledge Graph Builder",
    layout="wide"
)

# Custom CSS for modern dark/blue frontend
st.markdown("""
<style>
    /* Import Google Font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    
    /* Global Styles - Dark Theme */
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
        background-color: #0a0e27;
    }
    
    /* Main container background */
    .stApp {
        background: linear-gradient(135deg, #0a0e27 0%, #0f1433 100%);
    }
    
    /* Main header - Blue gradient */
    .main-header {
        background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
        padding: 2rem;
        border-radius: 20px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        border: 1px solid rgba(59,130,246,0.3);
    }
    
    .main-header h1 {
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        background: linear-gradient(135deg, #ffffff 0%, #bfdbfe 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .main-header p {
        font-size: 1rem;
        opacity: 0.95;
        color: #e0e7ff;
    }
    
    /* Sidebar styling - Dark blue */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
        border-right: 1px solid #1e3a8a;
    }
    
    [data-testid="stSidebar"] [data-testid="stMarkdown"] {
        color: #e2e8f0;
    }
    
    [data-testid="stSidebar"] [data-testid="stMarkdown"] h1,
    [data-testid="stSidebar"] [data-testid="stMarkdown"] h2,
    [data-testid="stSidebar"] [data-testid="stMarkdown"] h3 {
        color: #60a5fa;
    }
    
    /* Sidebar select box */
    [data-testid="stSidebar"] .stSelectbox label,
    [data-testid="stSidebar"] .stTextArea label {
        color: #94a3b8;
    }
    
    [data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] {
        background-color: #1e293b;
        border-color: #3b82f6;
    }
    
    /* Custom card styling - Dark blue */
    .custom-card {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        border-radius: 16px;
        padding: 1.5rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        border: 1px solid #1e3a8a;
        margin-bottom: 1rem;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .custom-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(59,130,246,0.2);
        border-color: #3b82f6;
    }
    
    /* Step indicators */
    .step-indicator {
        display: inline-block;
        width: 32px;
        height: 32px;
        background: linear-gradient(135deg, #3b82f6 0%, #1e3a8a 100%);
        color: white;
        border-radius: 50%;
        text-align: center;
        line-height: 32px;
        font-weight: bold;
        margin-right: 12px;
    }
    
    /* Metric cards - Dark theme */
    .metric-card {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        border-radius: 12px;
        padding: 1rem;
        text-align: center;
        border: 1px solid #1e3a8a;
        transition: all 0.3s;
    }
    
    .metric-card:hover {
        border-color: #3b82f6;
        box-shadow: 0 4px 12px rgba(59,130,246,0.2);
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .metric-label {
        font-size: 0.85rem;
        color: #94a3b8;
        margin-top: 0.5rem;
    }
    
    /* Button styling - Blue gradient */
    .stButton > button {
        background: linear-gradient(135deg, #3b82f6 0%, #1e3a8a 100%);
        color: white;
        border: none;
        padding: 0.65rem 1.5rem;
        font-weight: 600;
        border-radius: 10px;
        transition: all 0.3s;
        width: 100%;
        border: 1px solid rgba(255,255,255,0.1);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(59,130,246,0.4);
        background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
    }
    
    /* Tab styling - Dark theme */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: #0f172a;
        padding: 0.5rem;
        border-radius: 12px;
        border: 1px solid #1e3a8a;
    }
    
    .stTabs [data-baseweb="tab"] {
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-weight: 500;
        color: #94a3b8;
        background-color: transparent;
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #3b82f6 0%, #1e3a8a 100%);
        color: white;
    }
    
    /* Info box - Dark blue */
    .info-box {
        background: linear-gradient(135deg, #1e3a8a 0%, #1e293b 100%);
        border-left: 4px solid #3b82f6;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
        color: #e2e8f0;
    }
    
    /* Success/Error/Warning boxes */
    .stAlert {
        border-radius: 10px;
        border-left-width: 4px;
    }
    
    .stAlert [data-testid="stMarkdown"] {
        color: #e2e8f0;
    }
    
    /* Success message */
    div[data-testid="stSuccess"] {
        background: linear-gradient(135deg, #065f46 0%, #047857 100%);
        border-left-color: #10b981;
        color: white;
    }
    
    /* Info message */
    div[data-testid="stInfo"] {
        background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);
        border-left-color: #3b82f6;
        color: #e0e7ff;
    }
    
    /* Warning message */
    div[data-testid="stWarning"] {
        background: linear-gradient(135deg, #78350f 0%, #92400e 100%);
        border-left-color: #f59e0b;
        color: #fed7aa;
    }
    
    /* Error message */
    div[data-testid="stError"] {
        background: linear-gradient(135deg, #7f1d1d 0%, #991b1b 100%);
        border-left-color: #ef4444;
        color: #fecaca;
    }
    
    /* Dataframe styling */
    [data-testid="stDataFrame"] {
        border-radius: 12px;
        overflow: hidden;
    }
    
    .stDataFrame {
        background-color: #1e293b;
    }
    
    /* Concept tags - Blue theme */
    .concept-tag {
        display: inline-block;
        background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        margin: 0.25rem;
        font-size: 0.85rem;
        font-weight: 500;
        color: white;
        box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        transition: all 0.2s;
    }
    
    .concept-tag:hover {
        transform: scale(1.05);
        box-shadow: 0 2px 8px rgba(59,130,246,0.4);
    }
    
    /* Footer - Dark */
    .footer {
        text-align: center;
        padding: 2rem;
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        border-radius: 12px;
        margin-top: 3rem;
        border: 1px solid #1e3a8a;
    }
    
    .footer p {
        color: #94a3b8;
    }
    
    /* Headers - Blue theme */
    h1, h2, h3, h4, h5, h6 {
        color: #e2e8f0 !important;
    }
    
    /* Caption text */
    .stCaption {
        color: #94a3b8 !important;
    }
    
    /* Markdown text */
    [data-testid="stMarkdown"] {
        color: #cbd5e1;
    }
    
    /* Text area */
    .stTextArea textarea {
        background-color: #1e293b;
        color: #e2e8f0;
        border-color: #1e3a8a;
    }
    
    .stTextArea textarea:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 2px rgba(59,130,246,0.2);
    }
    
    /* Select box */
    .stSelectbox div[data-baseweb="select"] {
        background-color: #1e293b;
        color: #e2e8f0;
    }
    
    /* Spinner */
    .stSpinner > div {
        border-top-color: #3b82f6 !important;
    }
    
    /* JSON viewer */
    .stJson {
        background-color: #0f172a !important;
        border: 1px solid #1e3a8a !important;
        border-radius: 8px !important;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .main-header h1 {
            font-size: 1.75rem;
        }
        .metric-value {
            font-size: 1.5rem;
        }
    }
</style>
""", unsafe_allow_html=True)

# =====================================================
# HEADER
# =====================================================
st.markdown("""
<div class="main-header">
    <h1> AI Knowledge Graph Builder</h1>
    <p>Transform unstructured content into structured knowledge using Multi-Agent AI Pipeline</p>
</div>
""", unsafe_allow_html=True)

# =====================================================
# SIDEBAR
# =====================================================
with st.sidebar:
    st.markdown("###  Simulation Controls")
    st.markdown("---")
    
    selected_demo = st.selectbox(
        " Select Demo Topic",
        ["Custom Input"] + list(sample_topics.keys()),
        help="Choose a pre-defined example or enter your own content"
    )
    
    if selected_demo != "Custom Input":
        input_text = sample_topics[selected_demo]
        st.info(f" **Loaded:** {selected_demo}")
    else:
        input_text = st.text_area(
            " Paste Learning Content",
            height=220,
            placeholder="Enter your educational or technical content here...\n\nExample: The Solar System consists of the Sun and eight planets. Mercury is the closest planet to the Sun..."
        )
    
    st.markdown("---")
    
    generate = st.button(
        " Generate Knowledge Graph",
        use_container_width=True,
        type="primary"
    )
    
    st.markdown("---")
    st.markdown("""
    ###  Multi-Agent Pipeline
    1. **Extraction Agent** - Identifies key concepts
    2. **Relation Agent** - Maps semantic relationships
    3. **Graph Builder** - Creates visual knowledge graph
    4. **Refinement Agent** - Cleans and normalizes
    5. **Validation Agent** - Verifies integrity
    6. **Diff Viewer** - Tracks changes
    """)
    
    st.markdown("---")
    st.caption("⚡ Powered by spaCy · NetworkX · PyVis")

# =====================================================
# TABS
# =====================================================
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    " Graph Builder",
    " Analytics Dashboard",
    " Simulation History",
    " Agent Logs",
    " About Project"
])

# =====================================================
# MAIN TAB - GRAPH BUILDER
# =====================================================
with tab1:
    if generate:
        try:
            write_log("Simulation started")
            
            # =================================================
            # STEP 1 - INPUT CONTENT (LEFT ALIGNED)
            # =================================================
            st.markdown("---")
            st.markdown("##  Input Content")
            st.caption("The system receives unstructured educational content")
            st.markdown("---")
            
            st.info(f" **Content Length:** {len(input_text)} characters\n\n{input_text[:500]}{'...' if len(input_text) > 500 else ''}")
            
            # =================================================
            # STEP 2 - CONCEPT EXTRACTION (LEFT ALIGNED)
            # =================================================
            with st.spinner(" Extraction Agent is analyzing content..."):
                concepts = extract_concepts(input_text)
                write_log(f"{len(concepts)} concepts extracted")
            
            st.markdown("---")
            st.markdown("##  Concept Extraction")
            st.caption("Extraction Agent identifies important concepts and entities")
            st.markdown("---")
            
            # Display concepts as tags
            concept_html = '<div style="padding: 1rem; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-radius: 12px; border: 1px solid #1e3a8a;">'
            for concept in concepts:
                concept_html += f'<span class="concept-tag">{concept}</span>'
            concept_html += '</div>'
            st.markdown(concept_html, unsafe_allow_html=True)
            
            # =================================================
            # STEP 3 - RELATIONSHIP MAPPING (LEFT ALIGNED)
            # =================================================
            with st.spinner(" Relation Agent is mapping relationships..."):
                relationships = extract_relationships(input_text, concepts)
                write_log(f"{len(relationships)} relationships generated")
            
            st.markdown("---")
            st.markdown("##  Relationship Mapping")
            st.caption("Relation Agent maps semantic connections between concepts")
            st.markdown("---")
            
            if relationships:
                relation_rows = []
                for item in relationships:
                    relation_rows.append({
                        "Source": item["source"],
                        "Relation": item["relation"],
                        "Target": item["target"],
                        "Context": item["sentence"][:100] + "..." if len(item["sentence"]) > 100 else item["sentence"]
                    })
                relation_df = pd.DataFrame(relation_rows)
                st.dataframe(relation_df, use_container_width=True, height=400)
            else:
                st.warning("⚠️ No meaningful relationships detected.")
            
            # =================================================
            # STEP 4 - KNOWLEDGE GRAPH (LEFT ALIGNED)
            # =================================================
            with st.spinner(" Graph Builder Agent is constructing knowledge graph..."):
                graph = build_graph(relationships)
                graph_path = generate_pyvis_graph(graph)
                write_log("Graph generated successfully")
            
            st.markdown("---")
            st.markdown("##  Knowledge Graph")
            st.caption("Interactive visual representation of semantic relationships")
            st.markdown("---")
            
            # Metrics Row
            col1, col2, col3 = st.columns(3)
            with col1:
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value">{len(concepts)}</div>
                    <div class="metric-label">📌 Concepts</div>
                </div>
                """, unsafe_allow_html=True)
            with col2:
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value">{len(relationships)}</div>
                    <div class="metric-label">🔗 Relationships</div>
                </div>
                """, unsafe_allow_html=True)
            with col3:
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-value">{graph.number_of_nodes()}</div>
                    <div class="metric-label">🎯 Graph Nodes</div>
                </div>
                """, unsafe_allow_html=True)
            
            # Graph Display
            with open(graph_path, "r", encoding="utf-8") as file:
                html_data = file.read()
            components.html(html_data, height=650)
            
            # =================================================
            # STEP 5 - REFINEMENT AGENT (LEFT ALIGNED)
            # =================================================
            with st.spinner(" Refinement Agent is optimizing concepts..."):
                refined_concepts = refine_concepts(concepts)
                write_log("Concept refinement completed")
            
            st.markdown("---")
            st.markdown("##  Refinement Agent")
            st.caption("Removes redundancy, normalizes terminology, improves consistency")
            st.markdown("---")
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("###  Before Refinement")
                before_html = '<div style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); padding: 1rem; border-radius: 12px; border: 1px solid #1e3a8a;">'
                for concept in concepts:
                    before_html += f'<span class="concept-tag">{concept}</span>'
                before_html += '</div>'
                st.markdown(before_html, unsafe_allow_html=True)
            with col2:
                st.markdown("###  After Refinement")
                after_html = '<div style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); padding: 1rem; border-radius: 12px; border: 1px solid #1e3a8a;">'
                for concept in refined_concepts:
                    after_html += f'<span class="concept-tag">{concept}</span>'
                after_html += '</div>'
                st.markdown(after_html, unsafe_allow_html=True)
            
            # =================================================
            # STEP 6 - VALIDATION CHECKLIST (LEFT ALIGNED)
            # =================================================
            validation_results = validate_pipeline(refined_concepts, relationships, graph)
            
            st.markdown("---")
            st.markdown("##  Validation Checklist")
            st.caption("Validation Agent verifies graph integrity and pipeline completion")
            st.markdown("---")
            
            for key, value in validation_results.items():
                if value:
                    st.success(f"✅ {key}")
                else:
                    st.error(f"❌ {key}")
            
            # =================================================
            # STEP 7 - CHANGE DIFF VIEWER (LEFT ALIGNED)
            # =================================================
            st.markdown("---")
            st.markdown("##  Diff Viewer")
            st.caption("Compares concepts before and after refinement")
            st.markdown("---")
            
            diff = generate_diff(concepts, refined_concepts)
            st.json(diff)
            
            # Save History
            save_history(selected_demo, concepts, relationships)
            write_log("Simulation completed")
            
            # Success message (without balloons)
            st.success(" Knowledge Graph generated successfully! Explore the tabs for more insights.")
            
        except Exception as e:
            st.error(f"❌ An error occurred: {str(e)}")
            write_log(f"Error: {str(e)}")
    
    else:
        # Welcome message when no generation has occurred
        st.markdown("""
        <div class="custom-card" style="text-align: center; padding: 3rem;">
            <h2 style="color: #60a5fa;"> Ready to Build Your Knowledge Graph?</h2>
            <p style="color: #94a3b8; margin-top: 1rem;">
                Use the sidebar controls to select a demo topic or paste your own content,<br>
                then click "Generate Knowledge Graph" to start the multi-agent pipeline.
            </p>
            <div class="info-box" style="margin-top: 2rem; display: inline-block; text-align: left;">
                <strong> Quick Start:</strong><br>
                • Try the "Solar System" demo for astronomy concepts<br>
                • Or paste your own educational content<br>
                • Watch as AI extracts concepts and builds relationships
            </div>
        </div>
        """, unsafe_allow_html=True)

# =====================================================
# ANALYTICS TAB
# =====================================================
with tab2:
    st.markdown("##  Knowledge Graph Analytics")
    st.caption("Analyze graph complexity, semantic structure, and concept distribution")
    
    if generate and 'concepts' in locals():
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{len(set(concepts))}</div>
                <div class="metric-label">🎯 Unique Concepts</div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{len(relationships)}</div>
                <div class="metric-label">🔗 Total Relationships</div>
            </div>
            """, unsafe_allow_html=True)
        with col3:
            density = round(graph.number_of_edges() / max(graph.number_of_nodes(), 1), 2)
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{density}</div>
                <div class="metric-label"> Graph Density</div>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("---")
        st.markdown("###  Concept Distribution")
        concept_df = pd.DataFrame({"Concept": concepts})
        st.dataframe(concept_df, use_container_width=True, height=400)
        
        st.markdown("---")
        st.markdown("###  Relationship Statistics")
        if relationships:
            rel_types = [r['relation'] for r in relationships]
            rel_df = pd.DataFrame(rel_types, columns=["Relation Type"])
            st.dataframe(rel_df.value_counts().reset_index(), use_container_width=True)
    else:
        st.info(" Generate a knowledge graph first to view analytics.")

# =====================================================
# HISTORY TAB
# =====================================================
with tab3:
    st.markdown("## Simulation History")
    st.caption("Track previously generated knowledge graph simulations")
    
    history = load_history()
    if history:
        history_df = pd.DataFrame(history)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{len(history_df)}</div>
                <div class="metric-label">📊 Total Simulations</div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            avg_concepts = round(history_df["concept_count"].mean(), 1)
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{avg_concepts}</div>
                <div class="metric-label">📌 Avg. Concepts</div>
            </div>
            """, unsafe_allow_html=True)
        with col3:
            avg_rels = round(history_df["relationship_count"].mean(), 1)
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{avg_rels}</div>
                <div class="metric-label">🔗 Avg. Relationships</div>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("---")
        st.dataframe(history_df, use_container_width=True)
        
        latest = history[-1]
        st.markdown("---")
        st.markdown("###  Recent Simulation Insights")
        st.info(f"""
        **Latest Topic:** {latest['topic']}
        
        **Top Concepts:** {', '.join(latest['top_concepts'][:10])}
        
        **Relationships Generated:** {latest['relationship_count']}
        """)
    else:
        st.info("📭 No simulation history available yet. Generate a graph to see records.")

# =====================================================
# LOGS TAB
# =====================================================
with tab4:
    st.markdown("## Agent Execution Logs")
    st.caption("Monitor activity from Extraction, Relation, Graph Builder, Refinement, and Validation agents")
    
    try:
        with open("outputs/logs/agent_logs.txt", "r", encoding="utf-8") as file:
            logs = file.readlines()
        
        total_logs = len(logs)
        success_logs = len([line for line in logs if "completed" in line.lower()])
        
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{total_logs}</div>
                <div class="metric-label">📋 Total Log Events</div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{success_logs}</div>
                <div class="metric-label">✅ Completed Events</div>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("---")
        st.markdown("###  Execution Timeline")
        
        formatted_logs = "".join(logs[::-1])
        st.text_area("Logs", formatted_logs, height=500, key="logs_viewer")
        
    except FileNotFoundError:
        st.warning("📭 No logs available yet. Run a simulation to generate logs.")

# =====================================================
# ABOUT TAB
# =====================================================
with tab5:
    st.markdown("##  Project Overview")
    st.caption("AI-powered semantic knowledge graph generation using multi-agent processing")
    
    st.markdown("""
    <div class="custom-card">
        <h3>Project Objective</h3>
        <p>Build structured semantic knowledge graphs from unstructured educational or technical content. The system transforms raw text into interactive visual graphs using NLP-based concept extraction and relationship mapping.</p>
    </div>
    
    <div class="custom-card">
        <h3>Multi-Agent Pipeline</h3>
        <ul>
            <li><strong>Extraction Agent</strong> - Identifies important concepts, entities, and keywords</li>
            <li><strong>Relation Agent</strong> - Maps semantic relationships between concepts</li>
            <li><strong>Graph Builder Agent</strong> - Generates interactive knowledge graph</li>
            <li><strong>Refinement Agent</strong> - Removes noise and normalizes terminology</li>
            <li><strong>Validation Agent</strong> - Verifies graph integrity and completion</li>
            <li><strong>Diff Viewer Agent</strong> - Compares concept structures</li>
        </ul>
    </div>
    
    <div class="custom-card">
        <h3>Technologies Used</h3>
        <ul>
            <li>Streamlit - Interactive web framework</li>
            <li>spaCy - NLP processing</li>
            <li>NetworkX - Graph operations</li>
            <li>PyVis - Interactive visualization</li>
            <li>DeepDiff - Difference analysis</li>
            <li>Pandas - Data manipulation</li>
        </ul>
    </div>
    
    <div class="custom-card">
        <h3>Graph Categories</h3>
        <ul>
            <li>🔴 Security Concepts</li>
            <li>🔵 Technology Concepts</li>
            <li>🟣 Process Concepts</li>
            <li>🟡 Data Concepts</li>
            <li>🟢 General Concepts</li>
        </ul>
    </div>
    
    <div class="custom-card">
        <h3>Expected Workflow</h3>
        <p>Content Input → Concept Extraction → Relationship Mapping → Graph Building → Semantic Refinement → Validation → Diff Analysis</p>
    </div>
    """, unsafe_allow_html=True)

# =====================================================
# FOOTER
# =====================================================
st.markdown("""
<div class="footer">
    <p> Multi-Agent AI Pipeline | Semantic Knowledge Graph Generation</p>
    <p style="font-size: 0.8rem;">© 2026 AI Knowledge Graph Builder</p>
</div>
""", unsafe_allow_html=True)